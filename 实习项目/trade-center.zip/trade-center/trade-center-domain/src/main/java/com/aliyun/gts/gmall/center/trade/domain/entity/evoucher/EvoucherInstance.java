package com.aliyun.gts.gmall.center.trade.domain.entity.evoucher;

import com.aliyun.gts.gmall.center.trade.domain.dataobject.evoucher.TcEvoucherDO;
import lombok.Data;

@Data
public class EvoucherInstance extends TcEvoucherDO {

}
