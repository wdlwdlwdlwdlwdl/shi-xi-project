package com.aliyun.gts.gmall.center.trade.persistence.mapper;

import com.aliyun.gts.gmall.center.trade.domain.dataobject.evoucher.TcEvoucherDO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TcEvoucherMapper extends BaseMapper<TcEvoucherDO> {
}
