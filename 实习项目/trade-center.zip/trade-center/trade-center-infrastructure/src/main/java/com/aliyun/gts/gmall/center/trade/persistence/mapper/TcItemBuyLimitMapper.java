package com.aliyun.gts.gmall.center.trade.persistence.mapper;

import com.aliyun.gts.gmall.center.trade.domain.dataobject.TcItemBuyLimitDO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TcItemBuyLimitMapper extends BaseMapper<TcItemBuyLimitDO> {
}
