package com.aliyun.gts.gmall.test.trade.deposit;

import com.aliyun.gts.gmall.platform.pay.api.dto.output.dto.OrderRefundDTO;
import com.aliyun.gts.gmall.platform.pay.api.enums.RefundStatusEnum;
import com.aliyun.gts.gmall.platform.trade.common.constants.OrderStatusEnum;
import com.aliyun.gts.gmall.platform.trade.common.constants.ReversalStatusEnum;
import com.aliyun.gts.gmall.platform.trade.common.constants.StepOrderStatusEnum;
import com.aliyun.gts.gmall.platform.trade.core.util.DivideUtils;
import com.aliyun.gts.gmall.platform.trade.domain.entity.reversal.MainReversal;
import com.aliyun.gts.gmall.test.trade.base.BaseStepTest;
import com.aliyun.gts.gmall.test.trade.base.TestConstants;
import com.aliyun.gts.gmall.test.trade.base.message.BaseTestConsumer;
import com.aliyun.gts.gmall.test.trade.base.message.TestRefundSuccessConsumer;
import com.aliyun.gts.gmall.test.trade.base.message.TestReversalStatusChangeConsumer;
import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DepositTest4_售后退款 extends BaseStepTest {

    private void test_售后退款(long pointAmt) {
        // 商品 1元, 运费 90元, 定金比例 80% (0.8元), 平台佣金 10%
        long totalAmt1 = 80;
        long pointCount = pointAmt * 20;    // 1积分 = 1000原子积分 = 0.5元
        long realAmt1 = 80 - pointAmt;

        // 2阶段
        long tailFeeTotal = 200;
        long[] tailFee = {50, 150};
        long totalAmt = totalAmt1 + tailFeeTotal;
        long realAmt2 = 9020;

        // 创建订单
        long primaryOrderId = createOrder(TestConstants.DEP_ITEM_ID, TestConstants.DEP_SKU_ID, pointCount);

        // 支付
        payOrder(primaryOrderId);

        // 报尾款
        Map<String, String> form = new HashMap<>();
        form.put("ITEM_TAIL_FEE", String.valueOf(1.0 * tailFee[0] / 100));
        form.put("FREIGHT_FEE", String.valueOf(1.0 * tailFee[1] / 100));
        form.put("LAST_SEND_TIME", "2030-01-01 00:00:00");
        sellerHandle(primaryOrderId, form, false);

        // 买家确认
        customerConfirm(primaryOrderId);

        // 尾款支付
        payOrder(primaryOrderId);

        // 卖家发货
        sendDelivery(primaryOrderId);

        // 确认收货
        confirmReceive(primaryOrderId);
        waitAsync();    // 确认收货赠积分会update订单version

        // 退 10%
        BaseTestConsumer.clearAll();
        checkRemainFee(primaryOrderId, totalAmt, 1);
        long re1 = createRefundOnly(primaryOrderId, totalAmt / 10);
        List<Long> div1 = DivideUtils.divide(totalAmt / 10, Arrays.asList(pointAmt, realAmt1)); // 积分+现金
        List<Long> confirmPointDiv1 = DivideUtils.divide(div1.get(0), Arrays.asList(1L, 9L)); // 平台积分+卖家积分
        List<Long> confirmRealDiv1 = DivideUtils.divide(div1.get(1), Arrays.asList(1L, 9L)); // 平台现金+卖家现金
        checkStatus(primaryOrderId, 2,
                OrderStatusEnum.REVERSAL_DOING,
                StepOrderStatusEnum.STEP_FINISH,
                StepOrderStatusEnum.STEP_FINISH);
        checkReversalFee(re1,
                CheckFee.builder()
                        .realAmt(div1.get(1))
                        .pointAmt(div1.get(0))
                        .confirmPlatformRealAmt(confirmRealDiv1.get(0))
                        .confirmPlatformPointAmt(confirmPointDiv1.get(0))
                        .confirmSellerRealAmt(confirmRealDiv1.get(1))
                        .confirmSellerPointAmt(confirmPointDiv1.get(1))
                        .build(),
                CheckFee.builder()
                        .realAmt(0)
                        .pointAmt(0)
                        .build(),
                false);
        TestReversalStatusChangeConsumer.waitMessage(re1,
                ReversalStatusEnum.WAIT_SELLER_AGREE, null);

        // 卖家同意 (剩余 252分)
        BaseTestConsumer.clearAll();
        reSellerAgree(re1);
        waitAsync(primaryOrderId, OrderStatusEnum.REVERSAL_DOING);
        checkStatus(primaryOrderId, 2,
                OrderStatusEnum.ORDER_CONFIRM,
                StepOrderStatusEnum.STEP_FINISH,
                StepOrderStatusEnum.STEP_FINISH);
        checkRemainFee(primaryOrderId, totalAmt * 9 / 10, 1);
        checkRefundStatus(re1, ReversalStatusEnum.REVERSAL_OK,
                RefundStatusEnum.REFUND_SUCCESS,
                pointAmt > 0 ? RefundStatusEnum.REFUND_SUCCESS : null,
                realAmt1 > 0 ? RefundStatusEnum.REFUND_SUCCESS : null,
                null, null, null);
        TestReversalStatusChangeConsumer.waitMessage(re1,
                ReversalStatusEnum.WAIT_REFUND, ReversalStatusEnum.WAIT_SELLER_AGREE);
        TestReversalStatusChangeConsumer.waitMessage(re1,
                ReversalStatusEnum.REVERSAL_OK, ReversalStatusEnum.WAIT_REFUND);
        checkReversalFee(re1,
                CheckFee.builder()
                        .realAmt(div1.get(1))
                        .pointAmt(div1.get(0))
                        .confirmPlatformRealAmt(confirmRealDiv1.get(0))
                        .confirmPlatformPointAmt(confirmPointDiv1.get(0))
                        .confirmSellerRealAmt(confirmRealDiv1.get(1))
                        .confirmSellerPointAmt(confirmPointDiv1.get(1))
                        .build(),
                CheckFee.builder()
                        .realAmt(0)
                        .pointAmt(0)
                        .build(),
                true);

        MainReversal mr1 = getReversal(re1);
        OrderRefundDTO refund1 = getRefund(mr1, 1);
        TestRefundSuccessConsumer.waitMessage(refund1.getRefundId());

        // 退 70% (即196分, 定金全退(80-28), 尾款144)
        BaseTestConsumer.clearAll();
        long re2 = createRefundOnly(primaryOrderId, totalAmt * 7 / 10);
        List<Long> confirmPointDiv2 = DivideUtils.divide(pointAmt - div1.get(0), Arrays.asList(1L, 9L)); // 平台积分+卖家积分
        List<Long> confirmRealDiv2 = DivideUtils.divide(realAmt1 - div1.get(1), Arrays.asList(1L, 9L)); // 平台现金+卖家现金
        checkStatus(primaryOrderId, 2,
                OrderStatusEnum.REVERSAL_DOING,
                StepOrderStatusEnum.STEP_FINISH,
                StepOrderStatusEnum.STEP_FINISH);
        checkReversalFee(re2,
                CheckFee.builder()
                        .realAmt(realAmt1 - div1.get(1))
                        .pointAmt(pointAmt - div1.get(0))
                        .confirmPlatformRealAmt(confirmRealDiv2.get(0))
                        .confirmPlatformPointAmt(confirmPointDiv2.get(0))
                        .confirmSellerRealAmt(confirmRealDiv2.get(1))
                        .confirmSellerPointAmt(confirmPointDiv2.get(1))
                        .build(),
                CheckFee.builder()
                        .realAmt(144)
                        .pointAmt(0)
                        .confirmPlatformRealAmt(14)
                        .confirmSellerRealAmt(130)
                        .build(),
                false);
        TestReversalStatusChangeConsumer.waitMessage(re2,
                ReversalStatusEnum.WAIT_SELLER_AGREE, null);

        // 卖家同意
        BaseTestConsumer.clearAll();
        reSellerAgree(re2);
        waitAsync(primaryOrderId, OrderStatusEnum.REVERSAL_DOING);
        checkStatus(primaryOrderId, 2,
                OrderStatusEnum.ORDER_CONFIRM,
                StepOrderStatusEnum.STEP_FINISH,
                StepOrderStatusEnum.STEP_FINISH);
        checkRemainFee(primaryOrderId, totalAmt * 2 / 10, 1);
        checkRefundStatus(re2, ReversalStatusEnum.REVERSAL_OK,
                RefundStatusEnum.REFUND_SUCCESS,
                pointAmt > 0 ? RefundStatusEnum.REFUND_SUCCESS : null,
                realAmt1 > 0 ? RefundStatusEnum.REFUND_SUCCESS : null,
                RefundStatusEnum.REFUND_SUCCESS, null, RefundStatusEnum.REFUND_SUCCESS);
        TestReversalStatusChangeConsumer.waitMessage(re2,
                ReversalStatusEnum.WAIT_REFUND, ReversalStatusEnum.WAIT_SELLER_AGREE);
        TestReversalStatusChangeConsumer.waitMessage(re2,
                ReversalStatusEnum.REVERSAL_OK, ReversalStatusEnum.WAIT_REFUND);
        checkReversalFee(re2,
                CheckFee.builder()
                        .realAmt(realAmt1 - div1.get(1))
                        .pointAmt(pointAmt - div1.get(0))
                        .confirmPlatformRealAmt(confirmRealDiv2.get(0))
                        .confirmPlatformPointAmt(confirmPointDiv2.get(0))
                        .confirmSellerRealAmt(confirmRealDiv2.get(1))
                        .confirmSellerPointAmt(confirmPointDiv2.get(1))
                        .build(),
                CheckFee.builder()
                        .realAmt(144)
                        .pointAmt(0)
                        .confirmPlatformRealAmt(14)
                        .confirmSellerRealAmt(130)
                        .build(),
                true);

        MainReversal mr2 = getReversal(re2);
        OrderRefundDTO refund21 = getRefund(mr2, 1);
        OrderRefundDTO refund22 = getRefund(mr2, 2);
        TestRefundSuccessConsumer.waitMessage(refund21.getRefundId());
        TestRefundSuccessConsumer.waitMessage(refund22.getRefundId());

        // 退最后 20% (全部尾款)
        BaseTestConsumer.clearAll();
        long re3 = createRefundOnly(primaryOrderId, totalAmt * 2 / 10);
        List<Long> confirmRealDiv3 = DivideUtils.divide(totalAmt * 2 / 10, Arrays.asList(1L, 9L)); // 平台现金+卖家现金
        checkStatus(primaryOrderId, 2,
                OrderStatusEnum.REVERSAL_DOING,
                StepOrderStatusEnum.STEP_FINISH,
                StepOrderStatusEnum.STEP_FINISH);
        checkReversalFee(re3,
                CheckFee.builder()
                        .realAmt(0)
                        .pointAmt(0)
                        .build(),
                CheckFee.builder()
                        .realAmt(totalAmt * 2 / 10) // 56
                        .pointAmt(0)
                        .confirmPlatformRealAmt(confirmRealDiv3.get(0))
                        .confirmSellerRealAmt(confirmRealDiv3.get(1))
                        .build(),
                false);
        TestReversalStatusChangeConsumer.waitMessage(re3,
                ReversalStatusEnum.WAIT_SELLER_AGREE, null);

        // 卖家同意 (退完)
        BaseTestConsumer.clearAll();
        reSellerAgree(re3);
        waitAsync(primaryOrderId, OrderStatusEnum.REVERSAL_DOING);
        checkStatus(primaryOrderId, 2,
                OrderStatusEnum.REVERSAL_SUCCESS,
                StepOrderStatusEnum.STEP_FINISH,
                StepOrderStatusEnum.STEP_FINISH);
        checkRemainFee(primaryOrderId, 0, 1);
        checkRefundStatus(re3, ReversalStatusEnum.REVERSAL_OK,
                null, null, null,
                RefundStatusEnum.REFUND_SUCCESS, null, RefundStatusEnum.REFUND_SUCCESS);
        TestReversalStatusChangeConsumer.waitMessage(re3,
                ReversalStatusEnum.WAIT_REFUND, ReversalStatusEnum.WAIT_SELLER_AGREE);
        TestReversalStatusChangeConsumer.waitMessage(re3,
                ReversalStatusEnum.REVERSAL_OK, ReversalStatusEnum.WAIT_REFUND);
        checkReversalFee(re3,
                CheckFee.builder()
                        .realAmt(0)
                        .pointAmt(0)
                        .build(),
                CheckFee.builder()
                        .realAmt(totalAmt * 2 / 10) // 56
                        .pointAmt(0)
                        .confirmPlatformRealAmt(confirmRealDiv3.get(0))
                        .confirmSellerRealAmt(confirmRealDiv3.get(1))
                        .build(),
                true);

        MainReversal mr3 = getReversal(re3);
        OrderRefundDTO refund31 = getRefund(mr3, 1);
        OrderRefundDTO refund32 = getRefund(mr3, 2);
        Assert.assertNull(refund31);
        Assert.assertNotNull(refund32);
        TestRefundSuccessConsumer.waitMessage(refund32.getRefundId());
        // 未发订单状态消息
        //TestOrderStatusChangeConsumer.waitMessage(primaryOrderId, OrderStatusEnum.REVERSAL_SUCCESS);
    }

    @Test
    public void test_001_售后退款_现金() {
        test_售后退款(0);
    }

    @Test
    public void test_002_售后退款_积分() {
        test_售后退款(80);
    }

    @Test
    public void test_003_售后退款_混合() {
        test_售后退款(50);
    }
}
