package com.aliyun.gts.gmall.test.trade.normal;

import com.aliyun.gts.gmall.test.trade.base.BaseOrderTest;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.runners.MethodSorters;

/**

 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@Ignore
public class TcOrderPayMapperTest extends BaseOrderTest {
//    @Autowired
//    private TcOrderPayMapper tcOrderPayMapper;
//
//    @Test
//    public void test() {
//        TcOrderPayDO queryPay = new TcOrderPayDO();
//
//        UpdateWrapper<TcOrderPayDO> updatePay = new UpdateWrapper();
//        updatePay.setSql("pay_time = null where payment_id=\"P2021111116420850050587\" and cust_id=110587"
//            + " and primary_order_id=14070030000587 ");
//        tcOrderPayMapper.update(queryPay , updatePay);
//    }
}
