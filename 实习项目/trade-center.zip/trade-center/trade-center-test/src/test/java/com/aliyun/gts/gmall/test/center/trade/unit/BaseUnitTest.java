//package com.aliyun.gts.gmall.test.center.trade.unit;
//
//import org.junit.runner.RunWith;
//import org.mockito.junit.MockitoJUnitRunner;
//
//@RunWith(MockitoJUnitRunner.class)
//public abstract class BaseUnitTest {
//
//}
