package com.aliyun.gts.gmall.framework.api.log.sdk;

import com.aliyun.gts.gmall.framework.api.dto.ClientInfo;

/**
 * log-service 排掉了, 代码中用到改类
 */
public class OpLogCommonUtil {
    public static <T> void update(boolean success, ClientInfo clientInfo, String appId, String bizType, String id) {
    }

    public static <T> void addWithoutDiff(boolean success, ClientInfo clientInfo, String appId, String bizType, String id, String name) {
    }
}
