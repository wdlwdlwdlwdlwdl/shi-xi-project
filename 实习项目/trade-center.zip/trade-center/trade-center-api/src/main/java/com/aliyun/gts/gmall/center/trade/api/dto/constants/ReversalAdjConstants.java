package com.aliyun.gts.gmall.center.trade.api.dto.constants;

public interface ReversalAdjConstants {
    /**
     * 是否系统调整
     */
    String IS_ADJ = "isAdj";

    /**
     * 系统调整原因
     */
    String ADJ_REASON = "adjReason";
}

