package com.aliyun.gts.gmall.center.trade.api.dto.input;

import com.aliyun.gts.gmall.platform.trade.api.dto.input.order.confirm.ConfirmOrderInfoRpcReq;
import lombok.Data;

@Data
public class ConfirmOrderSplitReq extends ConfirmOrderInfoRpcReq {

}
