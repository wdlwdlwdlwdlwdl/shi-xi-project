ALTER TABLE `tc_order`
    MODIFY COLUMN `item_pic` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '商品主图oss地址';
