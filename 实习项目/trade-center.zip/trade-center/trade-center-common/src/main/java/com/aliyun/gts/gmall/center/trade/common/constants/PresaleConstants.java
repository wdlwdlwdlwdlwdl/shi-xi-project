package com.aliyun.gts.gmall.center.trade.common.constants;

public class PresaleConstants {

    public static final String TEMPLATE_NAME = "preSale";

    public static final String CONTEXT_TAIL_START = "tailStart";

    public static final String CONTEXT_TAIL_END = "tailEnd";
}
