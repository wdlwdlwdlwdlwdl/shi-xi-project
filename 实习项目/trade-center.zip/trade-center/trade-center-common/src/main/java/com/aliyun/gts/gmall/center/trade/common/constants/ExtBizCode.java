package com.aliyun.gts.gmall.center.trade.common.constants;

public class ExtBizCode {

    public static final String EVOUCHER = "EVOUCHER";
    public static final String NORMAL_TRADE = "NORMAL_TRADE"; //BizCodeEnum.NORMAL_TRADE.getCode();

    public static final String MATCH_ALL = "MATCH_ALL"; // 匹配所有业务身份, 兜底实现


    public static final String PRE_SALE = "PRE_SALE";   // 预售
    public static final String DEPOSIT = "DEPOSIT";     // 定金尾款
}
