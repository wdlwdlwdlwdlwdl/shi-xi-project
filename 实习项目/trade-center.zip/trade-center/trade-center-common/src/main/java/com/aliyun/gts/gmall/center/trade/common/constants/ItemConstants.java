package com.aliyun.gts.gmall.center.trade.common.constants;

/**
 * @author haibin.xhb
 * @description: TODO
 * @date 2021/10/22 10:27
 */
public class ItemConstants {
    public static final String COMBINE_ITEM = "combine_item";
}
