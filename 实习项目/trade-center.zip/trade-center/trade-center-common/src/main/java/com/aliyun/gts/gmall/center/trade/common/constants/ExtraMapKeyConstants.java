package com.aliyun.gts.gmall.center.trade.common.constants;

public class ExtraMapKeyConstants {
    public static final String ORDER_METHOD_SEARCH = "omSearch";
}
