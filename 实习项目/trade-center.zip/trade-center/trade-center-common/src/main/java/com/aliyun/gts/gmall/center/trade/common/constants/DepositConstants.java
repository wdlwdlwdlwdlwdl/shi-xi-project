package com.aliyun.gts.gmall.center.trade.common.constants;

public class DepositConstants {

    public static final String TEMPLATE_NAME = "deposit";

    public static final String CONTEXT_TAIL_DAYS = "tailDays";
}
