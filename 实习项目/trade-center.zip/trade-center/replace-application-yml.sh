##替换本地yml配置文件 $1 绝对路径文件 $2 相对路径yml地址
cp $1 trade-center-bootstrap/src/main/resources/$2
