package com.aliyun.gts.gmall.manager.biz.constant;

/**
 * @author Chen.mu
 * @Date 2022/12/16
 */
public interface UserFeatures {
    //是否重置过密码 Y是重置过 N和没有是没重置过
    String RESET_PWD="resetpwd";
    String RESET_PWD_Y="Y";
    String RESET_PWD_N="N";
}
