package com.aliyun.gts.gmall.manager.front.common.dto.input;

import lombok.Data;

/**
 * 日志打印 对象
 */
@Data
public class PrintLogReq {

    private String printLog;

}
