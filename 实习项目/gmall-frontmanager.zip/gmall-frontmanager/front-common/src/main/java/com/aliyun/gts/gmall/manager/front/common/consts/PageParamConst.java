package com.aliyun.gts.gmall.manager.front.common.consts;

public interface PageParamConst {

     Integer DEFAULT_PAGE_NO = 1;

     Integer DEFAULT_PAGE_SIZE = 20;

}
