package com.aliyun.gts.gmall.manager.front.item.dto.temp;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @Title: PromotionInfoTempVO.java
 * @Description: 优惠信息-temp
 * @author zhao.qi
 * @date 2024年11月13日 12:27:03
 * @version V1.0
 */
@Getter
@Setter
public class PromotionInfoTempVO {

}
