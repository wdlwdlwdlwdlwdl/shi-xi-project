package com.aliyun.gts.gmall.manager.front.item.dto.temp;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @Title: ItemEvaluationTempVO.java
 * @Description: 商品评论-temp
 * @author zhao.qi
 * @date 2024年11月13日 12:21:39
 * @version V1.0
 */
@Getter
@Setter
public class ItemEvaluationTempVO {

}
