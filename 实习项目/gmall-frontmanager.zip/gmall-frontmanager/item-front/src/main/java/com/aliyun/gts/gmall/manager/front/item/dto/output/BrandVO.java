package com.aliyun.gts.gmall.manager.front.item.dto.output;

import lombok.Data;

@Data
public class BrandVO {


    /** id */
    private Long id;


    /** 品牌名 */
    private String name;


}
