package com.aliyun.gts.gmall.manager.front.item.dto.output;

import com.aliyun.gts.gmall.framework.api.dto.AbstractOutputInfo;
import io.swagger.annotations.ApiModel;



@ApiModel(value = "商品图片返回对象")
public class ItemImgInfoVO extends AbstractOutputInfo {



}
