package com.aliyun.gts.gmall.manager.front.item.dto.output;

import lombok.Data;

@Data
public class ItemDetailLinkVO {

    private String shortLink;

    private String previewLink;
}
