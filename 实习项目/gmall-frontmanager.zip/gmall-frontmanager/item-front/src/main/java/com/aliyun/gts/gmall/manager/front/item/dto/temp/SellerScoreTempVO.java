package com.aliyun.gts.gmall.manager.front.item.dto.temp;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @Title: SellerScoreTempVO.java
 * @Description: 商家评分-temp
 * @author zhao.qi
 * @date 2024年11月13日 12:27:03
 * @version V1.0
 */
@Getter
@Setter
public class SellerScoreTempVO {

}
