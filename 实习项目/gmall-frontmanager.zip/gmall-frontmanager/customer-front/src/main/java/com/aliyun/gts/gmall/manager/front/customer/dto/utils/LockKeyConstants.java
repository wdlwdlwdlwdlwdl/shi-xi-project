package com.aliyun.gts.gmall.manager.front.customer.dto.utils;

public class LockKeyConstants {

    public static final String NEW_USER_COUPON_KEY_PREFIX = "NEW_USER_COUPON_";

    public static final long WAIT_TIME = 2;

    public static final long LEASE_TIME = 5;

}
