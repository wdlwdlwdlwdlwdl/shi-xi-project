package com.aliyun.gts.gmall.manager.front.customer.dto.input.query;

import com.aliyun.gts.gmall.manager.front.common.dto.LoginRestQuery;
import lombok.Data;

/**
 * 用户积分日志查询
 *
 * @author 俊贤
 * @date 2021/03/12
 */
@Data
public class AccountBookRestQuery extends LoginRestQuery {

}