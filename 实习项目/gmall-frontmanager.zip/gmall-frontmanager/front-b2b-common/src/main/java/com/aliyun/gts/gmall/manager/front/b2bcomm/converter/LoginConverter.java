package com.aliyun.gts.gmall.manager.front.b2bcomm.converter;

import org.mapstruct.Mapper;

/**
 * @author 俊贤
 * @date 2021/02/19
 */
@Mapper(componentModel = "spring")
public interface LoginConverter {
//
//    /**
//     * 登陆数据对外
//     * @param operatorDO
//     * @return
//     */
//    OperatorVO operator2Vo(OperatorDO operatorDO);
//
//    OperatorDO account2operator(AccountDTO accountDTO);
//
//    /**
//     * 供应商信息转换
//     * @param infoDTO
//     * @return
//     */
//    PurchaserDO purchaseInfo2Do(PurchaserInfoDTO infoDTO);
}