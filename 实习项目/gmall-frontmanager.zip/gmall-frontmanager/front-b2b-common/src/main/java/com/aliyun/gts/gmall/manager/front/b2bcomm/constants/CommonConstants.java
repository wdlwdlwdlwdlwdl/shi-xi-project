package com.aliyun.gts.gmall.manager.front.b2bcomm.constants;

/**
 * @author haibin.xhb
 * @description: TODO
 * @date 2021/2/3 20:15
 */
public class CommonConstants {

    public static String SESSION_KEY ="login_user";

    public static String COOKIE_KEY ="sessionId";

    public static String token = "token";

    public static String APP = "gmall";

    /**
     * 当前应用对应的场景
     */
    public static final String SCENE_CODE = "console";

}
