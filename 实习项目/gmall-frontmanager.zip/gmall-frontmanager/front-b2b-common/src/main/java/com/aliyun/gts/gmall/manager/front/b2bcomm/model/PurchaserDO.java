package com.aliyun.gts.gmall.manager.front.b2bcomm.model;

import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author haibin.xhb
 * @description: TODO
 * @date 2021/2/3 18:44
 */
//@ToString
//@Data
//public class PurchaserDO implements Serializable {
//    private Long               id;
//    private String             name;
//    private String             phone;
//    private String             email;
//}
