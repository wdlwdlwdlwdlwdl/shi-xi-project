package com.aliyun.gts.gmall.manager.front.b2bcomm.input;

import lombok.Data;

@Data
public class ContractTemplateReq extends CommonPageReq{

    String templateName;

    String uploaderName;

}
