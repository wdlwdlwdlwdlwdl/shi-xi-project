package com.aliyun.gts.gmall.manager.front.b2bcomm.utils;

public class LoginContextHolder {
//
//    /**
//     * 线程本地LoginContext
//     */
//    private static final ThreadLocal<OperatorDO> HOLDER = ThreadLocal.withInitial(OperatorDO::new);
//
//    /**
//     * 受保护构造函数
//     */
//    protected LoginContextHolder() {
//        throw new UnsupportedOperationException();
//    }
//
//    /**
//     * 获取当前用户上下文信息
//     *
//     * @return LoginContext
//     */
//    public static OperatorDO getLoginContext() {
//        return HOLDER.get();
//    }
//
//    /**
//     * 清除当前用户上下文
//     */
//    public static void clearLoginContext() {
//        HOLDER.remove();
//    }
}
