package com.aliyun.gts.gmall.manager.front.b2bcomm.input;

/**
 * 空的请求
 *
 * @author GTS
 * @date 2021/02/25
 */
public class EmptyQuery extends CommonReq {
}