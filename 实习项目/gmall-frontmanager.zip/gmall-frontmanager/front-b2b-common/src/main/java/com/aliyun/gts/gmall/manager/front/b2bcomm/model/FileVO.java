package com.aliyun.gts.gmall.manager.front.b2bcomm.model;

import lombok.Data;

@Data
public class FileVO {

    String fileName;

    String ossUrl;

}
