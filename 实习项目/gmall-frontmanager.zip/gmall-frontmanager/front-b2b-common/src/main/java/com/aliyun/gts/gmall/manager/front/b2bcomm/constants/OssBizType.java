package com.aliyun.gts.gmall.manager.front.b2bcomm.constants;

/**
 * 生成oss凭证时  用来根据业务类型选择bucket
 */
public enum OssBizType {
    USER,
    MATERIAL,
    SOURCING,
    TRADE
}
