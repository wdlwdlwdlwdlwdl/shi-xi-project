package com.aliyun.gts.gmall.manager.front.b2bcomm.converter;

/**
 * @author gshine
 * @since 2/25/21 5:42 PM
 */
public interface BaseDateFormatterConverter {

    String DATE_PATTERN_YYYYMMDDHHMMSS = "yyyy-MM-dd HH:mm:ss";

}
