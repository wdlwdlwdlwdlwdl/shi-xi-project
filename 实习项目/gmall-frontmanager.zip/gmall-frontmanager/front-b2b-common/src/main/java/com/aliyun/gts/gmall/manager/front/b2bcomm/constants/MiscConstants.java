package com.aliyun.gts.gmall.manager.front.b2bcomm.constants;

/**
 * @author haibin.xhb
 * @description: TODO
 * @date 2021/5/22 15:32
 */
public class MiscConstants {
    public static String appName="purchase-admin";

    public static String purchaser = "purchaser";
}
