package com.aliyun.gts.gmall.platform.trade.app.example;

/**
 * @author lich
 * @date 2019/9/23
 */
public class ExampleConstants {

    public static final String ORDER_TYPE_CODE = "999"; // orderType

    public static final String BIZ_CODE = "EXAMPLE"; // bizCode
}
