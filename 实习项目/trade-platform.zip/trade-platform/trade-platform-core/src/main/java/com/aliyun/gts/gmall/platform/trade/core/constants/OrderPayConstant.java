package com.aliyun.gts.gmall.platform.trade.core.constants;

/**
 * 部分常量改成动态配置
 *
 * @author xinchen
 */
public class OrderPayConstant {

    public static long PAY_TIMEOUT_SECEONDS = 30 * 60;
}
