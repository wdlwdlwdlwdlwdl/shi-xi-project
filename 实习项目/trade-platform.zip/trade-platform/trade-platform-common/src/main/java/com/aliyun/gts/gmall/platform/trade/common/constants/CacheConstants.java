package com.aliyun.gts.gmall.platform.trade.common.constants;

/**
 * 缓存key集合
 */
public class CacheConstants {

    public static final String CREATE_CHECK_ORDER = "CREATE_CHECK_ORDER_%s";

    public static final String CREATE_ORINGIN_ORDER_NO = "CREATE_ORINGIN_ORDER_NO_%s";

}
