package com.aliyun.gts.gmall.platform.trade.common.constants;

public class OrderTags {

    public static final String OVER_SALE = "overSale";
}
