package com.aliyun.gts.gmall.platform.trade.common.constants;

public class ReversalFeatureKey {

    public static final String SYS_REASON = "sysReason";
}
