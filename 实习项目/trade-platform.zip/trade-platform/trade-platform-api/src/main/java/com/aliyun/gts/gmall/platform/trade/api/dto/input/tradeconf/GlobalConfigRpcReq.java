package com.aliyun.gts.gmall.platform.trade.api.dto.input.tradeconf;

import com.aliyun.gts.gmall.framework.api.rpc.dto.AbstractQueryRpcRequest;
import lombok.Data;

@Data
public class GlobalConfigRpcReq extends AbstractQueryRpcRequest {

}
