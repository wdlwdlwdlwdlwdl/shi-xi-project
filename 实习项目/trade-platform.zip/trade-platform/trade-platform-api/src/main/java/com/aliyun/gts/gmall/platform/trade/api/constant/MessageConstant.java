package com.aliyun.gts.gmall.platform.trade.api.constant;

public class MessageConstant {

    public static final String SUCCESS = "SUCCESS";

    public static final String TRADE_PAY_REFUND= "TRADE_PAY_REFUND";

}
