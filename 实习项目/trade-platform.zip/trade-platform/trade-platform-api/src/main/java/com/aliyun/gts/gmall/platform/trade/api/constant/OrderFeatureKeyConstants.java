package com.aliyun.gts.gmall.platform.trade.api.constant;

@Deprecated
public class OrderFeatureKeyConstants {

    public static final String SELLER_ACCOUNT_INFO = "sellerAccountInfo";
}
