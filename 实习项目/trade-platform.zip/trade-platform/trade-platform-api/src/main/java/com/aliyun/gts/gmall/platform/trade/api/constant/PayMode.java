package com.aliyun.gts.gmall.platform.trade.api.constant;

public interface PayMode {

    String EPAY = "epay";

    String LOAN = "loan";

    String INSTALLMENT = "installment";

    String INVALID = "invalid";

}
