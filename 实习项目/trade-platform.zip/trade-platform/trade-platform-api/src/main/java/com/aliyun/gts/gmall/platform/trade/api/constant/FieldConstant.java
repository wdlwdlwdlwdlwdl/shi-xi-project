package com.aliyun.gts.gmall.platform.trade.api.constant;

/**
 * 常量集合工具类
 * shifeng
 * @version 1.0.1
 */
public interface FieldConstant {

    // ALL
    public static final String ALL = "all";

}
