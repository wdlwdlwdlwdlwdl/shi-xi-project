package com.aliyun.gts.gmall.platform.trade.api.dto.input.order.confirm;

import com.aliyun.gts.gmall.framework.api.dto.AbstractInputParam;
import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
@ApiModel
public class ConfirmPromotionInfo extends AbstractInputParam {


}
