## 使用：
1。拷贝 application.yml.example / application.yml.remote，去掉后缀作为本地启动配置文件，无须提交push
2。统一配置写入application.yml.example，提交并push，提前和应用负责人沟通
3。其他文件根据环境进行命名，线上环境由配管统一配置

## 说明：
1。 application.yml.example 本地的配置项，拷贝后可自行修改
2。 application.yml.remote 连接到中心读取配置项，无法自行修改
